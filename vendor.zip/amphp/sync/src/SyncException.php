<?php

namespace Amp\Sync;

class SyncException extends \Exception
{
}
