<?php

namespace Amp\Parallel\Sync;

class ChannelException extends \Exception
{
}
