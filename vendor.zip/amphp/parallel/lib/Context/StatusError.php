<?php

namespace Amp\Parallel\Context;

class StatusError extends \Error
{
}
