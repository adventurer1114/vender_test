<?php

namespace MrShan0\PHPFirestore;

class FireStoreErrorCodes
{
    const DOCUMENT_NOT_FOUND        = 404;
    const UNABLE_TO_RESOLVE_REQUEST = 500;
}
