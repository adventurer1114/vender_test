# Changelog

All notable changes to `Firestore PHP` will be documented in this file.

## 1.0.1 - 2019-01-16
 - Add method for casting floating point values
 - Document ID flipped on `getDocument` method

## 1.0.0 - 2018-04-20
 - Initial release
