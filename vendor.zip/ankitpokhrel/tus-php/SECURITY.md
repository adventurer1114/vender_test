# Security Policy

## Supported Versions

All security updates are available for following versions.

| Version         | Supported          |
| --------------- | ------------------ |
| 2.x.x           | :white_check_mark: |
| 1.x.x           | :white_check_mark: |
| 0.x.x           | :x:                |

## Reporting a Vulnerability

Please report any security issues directly to hello [at] ankit.pl
