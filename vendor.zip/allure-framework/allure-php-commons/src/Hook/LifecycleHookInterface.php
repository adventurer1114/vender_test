<?php

declare(strict_types=1);

namespace Qameta\Allure\Hook;

interface LifecycleHookInterface
{
}
