<?php

declare(strict_types=1);

namespace Qameta\Allure\PHPUnit\Test\Unit\Internal;

use Qameta\Allure\Hook\LifecycleHookInterface;

final class TestLifecycleHook implements LifecycleHookInterface
{
}
